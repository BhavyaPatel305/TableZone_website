<script src="index.js"></script>

<div class="col-md-12 footer">
	<div class="container">
		<div class="col-md-4">
			<h4>ALL PRODUCTS</h4>
          	<ul class="links">
                <li><a href="#"><i class="fa fa-caret-right"></i> View All Games</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> New Releases</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> Terrain Crate</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> Kings of War</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> Armada</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> Firefight</a></li>
            </ul>
		</div>


		<div class="col-md-4">
			<h4>RESOURCES</h4>
          	<ul class="links">
                <li><a href="#"><i class="fa fa-caret-right"></i> Deadzone Campaign</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> Free Rules</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> Easy Army</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> Pathfinder Program</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> Wallpapers</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i> clubs</a></li>
            </ul>
		</div>

		<div class="col-md-4">
			<h4>FOLLOW US</h4>
          	<ul class="links">
                <li><a href="#"><i class="fa fa-facebook fa-fw"></i> Facebook</a></li>
                <li><a href="#"><i class="fa fa-twitter fa-fw"></i> Twitter</a></li>
                <li><a href="#"><i class="fa fa-instagram fa-fw"></i> Instagram</a></li>
              
            </ul>
		</div>
	</div>
</div>
</body>
</html>