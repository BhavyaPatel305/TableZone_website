<?php
require 'header.php';
require 'footer.php';